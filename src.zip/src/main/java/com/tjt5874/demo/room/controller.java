package com.tjt5874.demo.room;

import com.tjt5874.demo.room.model.ChatMessageEntity;
import com.tjt5874.demo.room.repository.ChatMessageRepository;
import com.tjt5874.demo.room.RoomService;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.stereotype.Controller;

import java.time.LocalDateTime;

@Controller
public class controller {

    private final ChatMessageRepository chatMessageRepository;
    private final RoomService roomService;

    public controller(ChatMessageRepository chatMessageRepository, RoomService roomService) {
        this.chatMessageRepository = chatMessageRepository;
        this.roomService = roomService;
    }

    @MessageMapping("/chat.sendMessage")
    @SendTo("/topic/room/{roomCode}") // Room-specific topic
    public text sendMessage(@Payload text chatMessage, SimpMessageHeaderAccessor headerAccessor) {
        String roomCode = (String) headerAccessor.getSessionAttributes().get("roomCode");

        if (roomCode == null) {
            // Error handling - user not in a room
            return chatMessage;
        }

        // Save to DB with room code
        ChatMessageEntity entity = new ChatMessageEntity(
                chatMessage.getSender(),
                chatMessage.getContent(),
                chatMessage.getType() == null ? "CHAT" : chatMessage.getType().name(),
                roomCode,
                LocalDateTime.now()
        );
        chatMessageRepository.save(entity);

        return chatMessage;
    }

    @MessageMapping("/chat.joinRoom")
    @SendTo("/topic/room/{roomCode}") // Room-specific topic
    public text joinRoom(@Payload text msg, SimpMessageHeaderAccessor headerAccessor) {
        String roomCode = msg.getContent(); // Room code sent in content

        // Verify room exists
        if (!roomService.joinRoom(roomCode)) {
            // Send error back to user (you'll need to implement error handling)
            return msg;
        }

        headerAccessor.getSessionAttributes().put("username", msg.getSender());
        headerAccessor.getSessionAttributes().put("roomCode", roomCode);

        // Save join event with room code
        ChatMessageEntity entity = new ChatMessageEntity(
                msg.getSender(),
                msg.getSender() + " joined the room!",
                "JOIN",
                roomCode,
                LocalDateTime.now()
        );
        chatMessageRepository.save(entity);

        return msg;
    }

    @MessageMapping("/chat.leaveRoom")
    @SendTo("/topic/room/{roomCode}")
    public text leaveRoom(@Payload text msg, SimpMessageHeaderAccessor headerAccessor) {
        String roomCode = (String) headerAccessor.getSessionAttributes().get("roomCode");
        String username = msg.getSender();

        if (roomCode != null) {
            roomService.leaveRoom(roomCode, username);

            // Save leave event with room code
            ChatMessageEntity entity = new ChatMessageEntity(
                    username,
                    username + " left the room!",
                    "LEAVE",
                    roomCode,
                    LocalDateTime.now()
            );
            chatMessageRepository.save(entity);

            // Clear room from session
            headerAccessor.getSessionAttributes().remove("roomCode");
        }

        return msg;
    }
}