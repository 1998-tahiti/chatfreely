package com.tjt5874.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatRoomApplicationTests {

	@Test
	void contextLoads() {
	}

}
