package com.tjt5874.demo.room;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class text {

    private type type;
    private String content;
    private String sender;

}
