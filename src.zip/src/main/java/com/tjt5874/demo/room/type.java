package com.tjt5874.demo.room;

public enum type {

    CHAT,
    JOIN,
    LEAVE
}
