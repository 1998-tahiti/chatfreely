package com.tjt5874.demo.room;

import com.tjt5874.demo.room.model.ChatMessageEntity;
import com.tjt5874.demo.room.repository.ChatMessageRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/messages")
@CrossOrigin(origins = "*")
public class ChatHistoryController {

    private final ChatMessageRepository chatMessageRepository;

    public ChatHistoryController(ChatMessageRepository chatMessageRepository) {
        this.chatMessageRepository = chatMessageRepository;
    }

    @GetMapping("/history/{roomCode}")
    public ResponseEntity<List<text>> getRoomMessages(@PathVariable String roomCode) {
        List<ChatMessageEntity> entities = chatMessageRepository.findAllMessagesByRoom(roomCode);
        List<text> messages = entities.stream()
                .map(entity -> text.builder()
                        .type(type.valueOf(entity.getType()))
                        .content(entity.getContent())
                        .sender(entity.getSender())
                        .build())
                .collect(Collectors.toList());
        return ResponseEntity.ok(messages);
    }
}